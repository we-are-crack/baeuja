package we_are_crack.baeuja;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaeujaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaeujaApplication.class, args);
	}

}
