package we_are_crack.baeuja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaeujaApplicationTests {

	@Test
	void contextLoads() {
	}

}
